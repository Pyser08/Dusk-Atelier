#!/bin/sh
# 사용법: RisuBard 폴더 안에 이 폴더를 넣고   sh speed-patch/speed-patch.sh   (--check / --uninstall / --flush)
cd "$(dirname "$0")" || exit 1
ROOT="$(cd .. && pwd)"
if [ -x "$ROOT/bin/node" ]; then NODE="$ROOT/bin/node"; elif command -v node >/dev/null 2>&1; then NODE=node; else echo "Node.js를 찾을 수 없습니다."; exit 1; fi
"$NODE" rbu-speed-patch.cjs "$ROOT" "$@"
