@echo off
chcp 65001 >nul
rem 사용법: RisuBard 폴더 안에 이 폴더를 넣고 더블클릭 (서버를 먼저 끄세요)
cd /d "%~dp0"
set "ROOT=%~dp0.."
if exist "%ROOT%\bin\node.exe" (
  "%ROOT%\bin\node.exe" rbu-speed-patch.cjs "%ROOT%" %*
) else (
  where node >nul 2>nul && ( node rbu-speed-patch.cjs "%ROOT%" %* ) || echo Node.js를 찾을 수 없습니다.
)
echo.
pause
