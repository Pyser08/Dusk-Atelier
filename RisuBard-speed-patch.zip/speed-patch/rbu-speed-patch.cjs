#!/usr/bin/env node
'use strict';
/*
 * RisuBard 저장 속도 패치 (자동 적용기)
 *
 *   node rbu-speed-patch.cjs [RisuBard 폴더]            적용 (이미 적용돼 있으면 확인만)
 *   node rbu-speed-patch.cjs [폴더] --check             상태만 확인 (아무것도 바꾸지 않음)
 *   node rbu-speed-patch.cjs [폴더] --uninstall         원래대로 (저널을 먼저 합친 뒤)
 *   node rbu-speed-patch.cjs [폴더] --flush             저널만 manifest에 합치기
 *   옵션: --data <저장 폴더>  (RISUBARD_DATA_ROOT를 쓰는 경우)   --yes  (확인 질문 생략)
 *
 * 하는 일: server/node/file-kv.cjs 에서 에셋 하나를 저장할 때마다 manifest.json 전체를 다시 쓰는 부분을
 * "바뀐 줄만 저널에 덧붙이기"로 바꾼다. 줄 번호가 아니라 코드 모양으로 자리를 찾고, 한 군데라도
 * 정확히 찾지 못하면 아무것도 바꾸지 않는다. 바꾸기 전에 그 버전의 서버 파일과 함께 자체 시험을 돌린다.
 *
 * 반드시 RisuBard 서버를 끈 상태에서 실행하세요.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const VERSION = 1;
const MARK_RE = /\/\* RBU-SPEED-PATCH v(\d+) base=([0-9a-f]{64}) \*\//;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const say = (...a) => console.log(...a);
const fail = (msg, code = 1) => { console.error(`\n[중단] ${msg}`); process.exit(code); };

// ---------------------------------------------------------------- 인자
const argv = process.argv.slice(2);
const flag = f => argv.includes(f);
const opt = name => { const i = argv.indexOf(name); return i >= 0 ? argv[i + 1] : undefined; };
const positional = argv.filter((a, i) => !a.startsWith('--') && argv[i - 1] !== '--data');
const ROOT = path.resolve(positional[0] || process.cwd());
const MODE = flag('--uninstall') ? 'uninstall' : flag('--check') ? 'check' : flag('--flush') ? 'flush' : 'install';
const NODE_DIR = path.join(ROOT, 'server', 'node');
const FILE_KV = path.join(NODE_DIR, 'file-kv.cjs');
const BACKUP = `${FILE_KV}.rbu-backup`;

// ---------------------------------------------------------------- 코드 스캐너
// 문자열·템플릿·주석·정규식을 건너뛰며 짝 맞는 '}'를 찾는다.
function matchBrace(src, open) {
    let depth = 0, i = open;
    const tmpl = [];      // 템플릿 안 ${ } 깊이 스택
    let prevSig = '';
    while (i < src.length) {
        const c = src[i], n = src[i + 1];
        if (c === '/' && n === '/') { i = src.indexOf('\n', i); if (i < 0) return -1; continue; }
        if (c === '/' && n === '*') { i = src.indexOf('*/', i + 2); if (i < 0) return -1; i += 2; continue; }
        if (c === '"' || c === "'") {
            i++; while (i < src.length && src[i] !== c) { if (src[i] === '\\') i++; if (src[i] === '\n') return -1; i++; }
            i++; prevSig = 'a'; continue;
        }
        if (c === '`') { i = skipTemplate(src, i + 1); if (i < 0) return -1; prevSig = 'a'; continue; }
        if (c === '/' && (prevSig === '' || '(,=:[!&|?{};+-*%<>~^'.includes(prevSig))) {
            i++; let cls = false;
            while (i < src.length) { const d = src[i]; if (d === '\\') { i += 2; continue; } if (d === '\n') return -1;
                if (d === '[') cls = true; else if (d === ']') cls = false; else if (d === '/' && !cls) break; i++; }
            i++; while (/[a-z]/i.test(src[i] || '')) i++; prevSig = 'a'; continue;
        }
        if (c === '{') depth++;
        else if (c === '}') { depth--; if (depth === 0) return i; }
        if (!/\s/.test(c)) prevSig = /[\w$)\]]/.test(c) ? 'a' : c;
        i++;
    }
    return -1;
    function skipTemplate(s, j) {
        while (j < s.length) {
            if (s[j] === '\\') { j += 2; continue; }
            if (s[j] === '`') return j + 1;
            if (s[j] === '$' && s[j + 1] === '{') { const e = matchBrace(s, j + 1); if (e < 0) return -1; j = e + 1; continue; }
            j++;
        }
        return -1;
    }
}

// ---------------------------------------------------------------- 패치 (위치 기반)
const JOURNAL_CONSTS = `
// [RBU 속도 패치] manifest.json 대신 바뀐 항목만 덧붙이는 저널
const JOURNAL_PATH = 'kv/manifest.journal';
const JOURNAL_COMPACT_BYTES = Number(process.env.RISU_MANIFEST_JOURNAL_BYTES) || 32 * 1024 * 1024;
const JOURNAL_IDLE_MS = Number(process.env.RISU_MANIFEST_JOURNAL_IDLE_MS) || 10000;
const rbuJournalFlushers = new Set();
let rbuExitHooked = false;
function rbuHookExit() {
    if (rbuExitHooked) return;
    rbuExitHooked = true;
    // 정상 종료(process.exit 포함) 때 저널을 manifest.json에 합친다. 순정 서버로 바뀌어도 잃는 게 없게.
    process.on('exit', () => { for (const f of rbuJournalFlushers) { try { f(); } catch (e) { console.error('[RBU] journal flush on exit failed:', e?.message ?? e); } } });
}
`;

const HELPERS = ind => `
${ind}function snapshotBase() {
${ind}    try { return fs.readFileSync(path.join(dataRoot, \`\${MANIFEST_PATH}.sha256\`), 'utf8').trim(); }
${ind}    catch { return 'none'; }
${ind}}

${ind}function fsyncKvDirectory() {
${ind}    const fd = fs.openSync(path.dirname(journalFile), 'r');
${ind}    try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
${ind}}

${ind}function removeJournal() {
${ind}    if (journalIdleTimer) { clearTimeout(journalIdleTimer); journalIdleTimer = null; }
${ind}    if (!fs.existsSync(journalFile)) { journalBytes = 0; return; }
${ind}    fs.rmSync(journalFile, { force: true });
${ind}    fsyncKvDirectory();
${ind}    journalBytes = 0;
${ind}}

${ind}// 저널 형식: 1행 = "H <이 저널이 이어 붙는 manifest.json.sha256>", 이후 한 묶음당 한 줄
${ind}// "<sha256(payload) 앞 16자> <payload JSON [[key, entry], ...]>". 줄바꿈으로 끝나고 체크섬이 맞는 줄만 인정한다.
${ind}function replayJournal(target) {
${ind}    journalBytes = 0;
${ind}    if (!fs.existsSync(journalFile)) return false;
${ind}    const raw = fs.readFileSync(journalFile);
${ind}    let offset = 0, good = 0, applied = 0, first = true, usable = true;
${ind}    while (offset < raw.length) {
${ind}        const nl = raw.indexOf(10, offset);
${ind}        if (nl === -1) break;
${ind}        const line = raw.toString('utf8', offset, nl);
${ind}        if (first) {
${ind}            first = false;
${ind}            if (line !== \`H \${snapshotBase()}\`) { usable = false; break; }
${ind}        } else {
${ind}            const sp = line.indexOf(' ');
${ind}            const payload = sp === -1 ? null : line.slice(sp + 1);
${ind}            if (payload === null || digest(payload).slice(0, 16) !== line.slice(0, sp)) break;
${ind}            let ops;
${ind}            try { ops = JSON.parse(payload); } catch { break; }
${ind}            for (const [key, entry] of ops) target.entries[key] = entry;
${ind}            applied += ops.length;
${ind}        }
${ind}        offset = nl + 1;
${ind}        good = offset;
${ind}    }
${ind}    if (!usable) {
${ind}        // manifest.json이 저널과 무관하게 바뀌었다(복원 등). 지우지 않고 옆에 남긴다.
${ind}        const kept = \`\${journalFile}.stale-\${Date.now()}\`;
${ind}        try { fs.renameSync(journalFile, kept); console.warn('[RBU] stale manifest journal kept as', kept); } catch { fs.rmSync(journalFile, { force: true }); }
${ind}        journalBytes = 0;
${ind}        return false;
${ind}    }
${ind}    if (good < raw.length) fs.truncateSync(journalFile, good);
${ind}    journalBytes = good;
${ind}    return applied > 0;
${ind}}

${ind}function appendJournal(prepared) {
${ind}    const payload = JSON.stringify(prepared);
${ind}    let text = \`\${digest(payload).slice(0, 16)} \${payload}\\n\`;
${ind}    const fresh = !fs.existsSync(journalFile) || journalBytes === 0;
${ind}    if (fresh) text = \`H \${snapshotBase()}\\n\${text}\`;
${ind}    const line = Buffer.from(text, 'utf8');
${ind}    const fd = fs.openSync(journalFile, fresh ? 'w' : 'a');
${ind}    try { fs.writeSync(fd, line); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
${ind}    if (fresh) fsyncKvDirectory();
${ind}    journalBytes += line.length;
${ind}    if (journalBytes > JOURNAL_COMPACT_BYTES) { saveManifest(); return; }
${ind}    // 저장이 잠잠해지면 합친다: 저널에 남는 건 길어야 몇 초 분량
${ind}    if (journalIdleTimer) clearTimeout(journalIdleTimer);
${ind}    journalIdleTimer = setTimeout(() => {
${ind}        journalIdleTimer = null;
${ind}        try { if (journalBytes > 0) saveManifest(); } catch (e) { console.error('[RBU] idle journal compaction failed:', e?.message ?? e); }
${ind}    }, JOURNAL_IDLE_MS);
${ind}    journalIdleTimer.unref?.();
${ind}}
`;

function patchSource(src) {
    const problems = [];
    const once = (re, label, from = 0) => {
        const g = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
        g.lastIndex = from;
        const all = [...src.slice(from).matchAll(new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'))];
        if (all.length !== 1) { problems.push(`${label}: ${all.length}곳`); return null; }
        const m = all[0]; m.index += from; return m;
    };
    const bodyOf = (re, label) => {
        const m = once(re, label);
        if (!m) return null;
        const open = src.indexOf('{', m.index + m[0].length - 1);
        const close = matchBrace(src, open);
        if (close < 0) { problems.push(`${label}: 본문 끝을 찾지 못함`); return null; }
        return { start: open + 1, end: close, text: src.slice(open + 1, close) };
    };
    const countIn = (text, s) => text.split(s).length - 1;

    if (/manifest\.journal/.test(src)) problems.push('이미 저널 코드가 들어 있음(다른 패치가 적용된 파일)');

    // 고칠 자리 찾기 (원본 기준 위치)
    const mManifestConst = once(/^const MANIFEST_PATH = .+;[ \t]*$/m, 'MANIFEST_PATH 상수');
    const mCreate = once(/^function createFileKv\(/m, 'createFileKv 함수');
    const mLetManifest = once(/^([ \t]*)let manifest = fs\.existsSync\(path\.join\(dataRoot, MANIFEST_PATH\)\)/m, 'manifest 읽는 곳');
    const mRetired = mLetManifest ? once(/^([ \t]*)let retired = loadRetired\(\);[ \t]*$/m, 'manifest 검사 다음 줄', mLetManifest.index) : null;
    const mSave = once(/^([ \t]*)function saveManifest\(\) \{/m, 'saveManifest 함수');
    const bSave = bodyOf(/function saveManifest\(\) \{/m, 'saveManifest 본문');
    const bKvSet = bodyOf(/function kvSet\(key, value\) \{/m, 'kvSet 본문');
    const bMany = bodyOf(/async function kvSetManyAsync\(\w+\) \{/m, 'kvSetManyAsync 본문');
    const bReload = bodyOf(/function reloadManifest\(\) \{/m, 'reloadManifest 본문');
    const mMigrate = once(/^([ \t]*)migrateLegacyHexFiles\(\);[ \t]*$/m, 'migrateLegacyHexFiles 호출');
    const mReturn = mMigrate ? once(/^([ \t]*)return \{[ \t]*$/m, '돌려주는 객체', mMigrate.index) : null;

    if (bSave && countIn(bSave.text, 'atomicWriteFile(dataRoot, MANIFEST_PATH') !== 1) problems.push('saveManifest: manifest 쓰는 줄이 1개가 아님');
    if (bKvSet && (countIn(bKvSet.text, 'saveManifest();') !== 1 || countIn(bKvSet.text, 'manifest.entries[key] =') !== 1)) problems.push('kvSet: 모양이 예상과 다름');
    if (bMany && (countIn(bMany.text, 'const prepared =') !== 1 || countIn(bMany.text, 'saveManifest()') !== 1 || !/for \(const \[key, entry\] of prepared\) manifest\.entries\[key\] = entry;/.test(bMany.text)))
        problems.push('kvSetManyAsync: 모양이 예상과 다름');
    if (bReload && (!/const next = readVerifiedJson\(dataRoot, MANIFEST_PATH\)/.test(bReload.text) || countIn(bReload.text, 'const nextRetired = loadRetired();') !== 1 || countIn(bReload.text, 'manifest = next;') !== 1))
        problems.push('reloadManifest: 모양이 예상과 다름');
    if (mCreate && mLetManifest && mLetManifest.index < mCreate.index) problems.push('manifest 읽는 곳이 createFileKv 밖에 있음');
    if (mRetired && mSave && mRetired.index > mSave.index) problems.push('함수 순서가 예상과 다름');
    if (problems.length) return { ok: false, problems };

    // 편집 목록 (뒤에서부터 적용해 위치가 밀리지 않게)
    const edits = [];
    const ins = (at, text) => edits.push({ at, del: 0, text });
    const rep = (at, len, text) => edits.push({ at, del: len, text });
    const lineEnd = i => { const e = src.indexOf('\n', i); return e < 0 ? src.length : e; };
    const ind = mLetManifest[1];

    ins(lineEnd(mManifestConst.index) + 1, JOURNAL_CONSTS);
    ins(mLetManifest.index, `${ind}const journalFile = path.join(dataRoot, JOURNAL_PATH);\n${ind}let journalBytes = 0;\n${ind}let journalIdleTimer = null;\n`);
    ins(mRetired.index, `${ind}const replayedOnOpen = replayJournal(manifest);\n`);
    ins(mSave.index, HELPERS(mSave[1]).replace(/^\n/, '') + '\n');
    { const k = bSave.start + bSave.text.indexOf('atomicWriteFile(dataRoot, MANIFEST_PATH'); ins(lineEnd(k), `\n${mSave[1]}    removeJournal(); // [RBU] manifest.json이 저널 내용을 모두 담았다`); }
    { const k = bKvSet.start + bKvSet.text.indexOf('saveManifest();'); rep(k, 'saveManifest();'.length, 'appendJournal([[key, manifest.entries[key]]]); // [RBU]'); }
    { const k = bMany.start + bMany.text.indexOf('saveManifest()'); rep(k, 'saveManifest()'.length, 'appendJournal(prepared) /* [RBU] */'); }
    { const k = bReload.start + bReload.text.indexOf('const nextRetired = loadRetired();');
      const ls = src.lastIndexOf('\n', k) + 1; ins(ls, `${src.slice(ls, k)}replayJournal(next); // [RBU]\n`); }
    { const mi = mMigrate[1];
      ins(lineEnd(mMigrate.index) + 1,
        `${mi}if (replayedOnOpen) saveManifest(); // [RBU] 다시 켤 때 저널을 manifest.json에 합친다\n` +
        `${mi}rbuJournalFlushers.add(() => { if (journalBytes > 0) saveManifest(); });\n${mi}rbuHookExit();\n`);
      ins(lineEnd(mReturn.index) + 1, `${mi}    flushManifest() { if (journalBytes > 0) saveManifest(); }, // [RBU]\n`); }

    edits.sort((a, b) => b.at - a.at);
    let out = src;
    for (const e of edits) out = out.slice(0, e.at) + e.text + out.slice(e.at + e.del);
    out = `/* RBU-SPEED-PATCH v${VERSION} base=${sha(Buffer.from(src))} */\n` + out;
    return { ok: true, source: out };
}

// ---------------------------------------------------------------- 자체 시험 (자식 프로세스, 임시 폴더)
const SELFTEST = String.raw`
'use strict';
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const lib = process.argv[2];
const { spawnSync } = require('child_process');
if (process.argv[3] === 'exitchild') {
    const { createFileKv } = require(lib);
    const kv = createFileKv({ dataRoot: process.argv[4] });
    for (let i = 0; i < 20; i++) kv.kvSet('assets/e' + i + '.png', Buffer.from('E' + i));
    if (!fs.existsSync(path.join(process.argv[4], 'kv/manifest.journal'))) { console.log('NOJOURNAL'); process.exit(3); }
    process.exit(0);
}
if (process.argv[3] === 'crashchild') {
    const { createFileKv } = require(lib);
    const kv = createFileKv({ dataRoot: process.argv[4] });
    for (let i = Number(process.argv[5]); ; i++) { kv.kvSet('assets/r' + i + '.png', Buffer.from('v' + i)); fs.writeSync(1, i + '\n'); }
}
const { createFileKv } = require(lib);
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'rbu-st-'));
const J = d => path.join(d, 'kv/manifest.journal'), M = d => path.join(d, 'kv/manifest.json');
const dirs = [];
const T = (name, fn) => { const d = tmp(); dirs.push(d); fn(d); };
(async () => {
try {
T('kvSet은 manifest.json을 다시 쓰지 않고 저널에 쓴다', d => {
    const kv = createFileKv({ dataRoot: d }); kv.kvSet('assets/a.png', Buffer.from('A'));
    const before = fs.existsSync(M(d)) ? fs.statSync(M(d)).mtimeMs : 0;
    kv.kvSet('assets/b.png', Buffer.from('B'));
    assert.equal(fs.existsSync(M(d)) ? fs.statSync(M(d)).mtimeMs : 0, before);
    assert.ok(fs.existsSync(J(d))); assert.equal(kv.kvGet('assets/b.png').toString(), 'B');
});
T('다시 열면 저널을 합친다', d => {
    let kv = createFileKv({ dataRoot: d });
    for (let i = 0; i < 30; i++) kv.kvSet('assets/' + i + '.png', Buffer.from(String(i)));
    kv.kvSet('database/database.bin', Buffer.from('db2'));
    kv = createFileKv({ dataRoot: d });
    for (let i = 0; i < 30; i++) assert.equal(kv.kvGet('assets/' + i + '.png').toString(), String(i));
    assert.equal(kv.kvGet('database/database.bin').toString(), 'db2');
    assert.ok(!fs.existsSync(J(d)));
    assert.ok(JSON.parse(fs.readFileSync(M(d), 'utf8')).entries['assets/29.png']);
});
T('묶음 저장·단일 저장·삭제 순서 보존', async d => {});
{
    const d = tmp(); dirs.push(d);
    let kv = createFileKv({ dataRoot: d }); const model = new Map();
    for (let i = 0; i < 200; i++) {
        const key = 'assets/k' + (i % 23) + '.png', r = i % 6;
        if (r === 0) { kv.kvDel(key); model.delete(key); }
        else if (r === 1) { const es = [0, 1, 2].map(j => ({ key: 'assets/k' + ((i + j) % 23) + '.png', value: Buffer.from('m' + i + j) })); await kv.kvSetManyAsync(es); for (const e of es) model.set(e.key, e.value.toString()); }
        else { kv.kvSet(key, Buffer.from('s' + i)); model.set(key, 's' + i); }
    }
    const check = k => { for (const [key, v] of model) assert.equal(k.kvGet(key)?.toString(), v, key); assert.deepEqual(k.kvList('assets/').sort(), [...model.keys()].sort()); };
    check(kv); check(createFileKv({ dataRoot: d }));
}
T('잘린 마지막 줄은 그 한 건만 버린다', d => {
    let kv = createFileKv({ dataRoot: d }); kv.kvSet('assets/x.png', Buffer.from('X')); kv.kvSet('assets/y.png', Buffer.from('Y'));
    const raw = fs.readFileSync(J(d)); fs.writeFileSync(J(d), raw.subarray(0, raw.length - 4));
    kv = createFileKv({ dataRoot: d }); assert.equal(kv.kvGet('assets/x.png').toString(), 'X'); assert.equal(kv.kvGet('assets/y.png'), null);
});
T('manifest.json이 바뀐 뒤의 낡은 저널은 적용하지 않고 옆에 남긴다', d => {
    let kv = createFileKv({ dataRoot: d }); kv.kvSet('assets/o.png', Buffer.from('O')); kv.flushManifest(); kv.kvSet('assets/j.png', Buffer.from('J'));
    const crypto = require('crypto'); const bytes = Buffer.from(JSON.stringify({ schemaVersion: 1, updatedAt: 1, entries: {} }, null, 2) + '\n');
    fs.writeFileSync(M(d), bytes); fs.writeFileSync(M(d) + '.sha256', crypto.createHash('sha256').update(bytes).digest('hex') + '\n');
    kv.reloadManifest(); assert.equal(kv.kvGet('assets/j.png'), null); assert.ok(!fs.existsSync(J(d)));
    assert.ok(fs.readdirSync(path.join(d, 'kv')).some(n => n.startsWith('manifest.journal.stale-')));
});
{
    const d = tmp(); dirs.push(d);
    const r = spawnSync(process.execPath, [__filename, lib, 'exitchild', d], { encoding: 'utf8' });
    assert.equal(r.status, 0, 'exit child: ' + r.stdout + r.stderr);
    assert.ok(!fs.existsSync(J(d)), '정상 종료 때 저널이 합쳐져야 함');
    const m = JSON.parse(fs.readFileSync(M(d), 'utf8')).entries; assert.ok(m['assets/e19.png'], '종료 후 manifest.json에 반영');
}
{
    process.env.RISU_MANIFEST_JOURNAL_IDLE_MS = '150';
    delete require.cache[require.resolve(lib)];
    const fresh = require(lib);
    const d = tmp(); dirs.push(d);
    const kv = fresh.createFileKv({ dataRoot: d }); kv.kvSet('assets/i.png', Buffer.from('I'));
    assert.ok(fs.existsSync(J(d)));
    await new Promise(r => setTimeout(r, 600));
    assert.ok(!fs.existsSync(J(d)), '잠잠해지면 저널이 합쳐져야 함');
    assert.ok(JSON.parse(fs.readFileSync(M(d), 'utf8')).entries['assets/i.png']);
}
{
    // 강제 종료(kill -9): 저장 완료로 응답한 것은 모두 남아야 한다
    const d = tmp(); dirs.push(d); let next = 0, acked = [], bad = 0;
    for (let round = 0; round < 6; round++) {
        const r = spawnSync(process.execPath, [__filename, lib, 'crashchild', d, String(next)], { encoding: 'utf8', timeout: 150 + round * 40, killSignal: 'SIGKILL' });
        const ids = (r.stdout || '').split('\n').filter(Boolean).map(Number); acked.push(...ids);
        if (ids.length) next = ids[ids.length - 1] + 2; else next += 1;
        const kv = createFileKv({ dataRoot: d });
        for (const i of acked) if (kv.kvGet('assets/r' + i + '.png')?.toString() !== 'v' + i) bad++;
    }
    assert.equal(bad, 0, 'kill -9 뒤 잃은 저장 ' + bad + '건');
    console.log('KILL9 acked=' + acked.length);
}
console.log('SELFTEST OK');
} catch (e) { console.log('SELFTEST FAIL', e && e.stack || e); process.exitCode = 1; }
finally { for (const d of dirs) try { fs.rmSync(d, { recursive: true, force: true }); } catch {} }
})();
`;

function runSelfTest(candidateSource) {
    const cand = path.join(NODE_DIR, `.file-kv.rbu-selftest-${process.pid}.cjs`);
    const script = path.join(os.tmpdir(), `rbu-selftest-${process.pid}.cjs`);
    fs.writeFileSync(cand, candidateSource);
    fs.writeFileSync(script, SELFTEST);
    try {
        const r = spawnSync(process.execPath, [script, cand], { encoding: 'utf8', timeout: 180000 });
        const out = (r.stdout || '') + (r.stderr || '');
        return { ok: r.status === 0 && /SELFTEST OK/.test(out), out };
    } finally {
        try { fs.unlinkSync(cand); } catch {}
        try { fs.unlinkSync(script); } catch {}
    }
}

// ---------------------------------------------------------------- 저널 합치기 (서버가 꺼진 상태에서)
function dataRootOf() {
    if (opt('--data')) return path.resolve(opt('--data'));
    try { return require(path.join(NODE_DIR, 'data-root.cjs')).resolveDataRoot({ cwd: ROOT }); }
    catch { return path.join(ROOT, 'save'); }
}
// 지금 file-kv.cjs(패치된 것)로 저장소를 한 번 열면 저널이 manifest.json에 합쳐진다.
function flushWith(libPath, dataRoot) {
    const code = `const {createFileKv}=require(${JSON.stringify(libPath)});const kv=createFileKv({dataRoot:${JSON.stringify(dataRoot)}});if(kv.flushManifest)kv.flushManifest();`;
    const r = spawnSync(process.execPath, ['-e', code], { cwd: ROOT, encoding: 'utf8', timeout: 600000 });
    if (r.status !== 0) throw new Error((r.stderr || r.stdout || '').trim().split('\n').slice(-5).join('\n'));
}
function journalPath(dataRoot) { return path.join(dataRoot, 'kv', 'manifest.journal'); }

// manifest와 맞지 않아 보관된 저널(.stale-*, .rbu-saved-*)에서, 지금 목록에 "없는" 항목만 되살린다.
// 이미 있는 키(예: database.bin)는 그 뒤에 저장된 더 새 값이므로 건드리지 않는다. 실제 파일이 남아 있는 것만.
function recoverOrphans(libPath, dataRoot, files) {
    if (!files.length) return { restored: 0, gone: 0, files: 0 };
    const code = `
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {createFileKv}=require(${JSON.stringify(libPath)});
const root=${JSON.stringify(dataRoot)}, files=${JSON.stringify(files)};
const kv=createFileKv({dataRoot:root});
const have=new Set(kv.kvList(''));
const add=new Map();
for(const f of files){
  const raw=fs.readFileSync(path.join(root,'kv',f));let off=0,first=true;
  while(off<raw.length){const nl=raw.indexOf(10,off);if(nl<0)break;const line=raw.toString('utf8',off,nl);off=nl+1;
    if(first){first=false;if(line.startsWith('H '))continue;}
    const sp=line.indexOf(' ');if(sp<0)break;const payload=line.slice(sp+1);
    if(crypto.createHash('sha256').update(payload).digest('hex').slice(0,16)!==line.slice(0,sp))break;
    let ops;try{ops=JSON.parse(payload)}catch{break}
    for(const [k,e] of ops){ if(!have.has(k)&&e&&/^[a-f0-9]{64}$/.test(e.object)) add.set(k,e); } }
}
let restored=0,gone=0;const entries=[];
for(const [k,e] of add){const p=path.join(root,'kv','objects',e.object);
  if(!fs.existsSync(p)){gone++;continue;} const b=fs.readFileSync(p);
  if(crypto.createHash('sha256').update(b).digest('hex')!==e.object){gone++;continue;} entries.push({key:k,value:b});}
(async()=>{for(let i=0;i<entries.length;i+=200) await kv.kvSetManyAsync(entries.slice(i,i+200)); restored=entries.length; kv.flushManifest&&kv.flushManifest();
 for(const f of files) fs.renameSync(path.join(root,'kv',f), path.join(root,'kv',f+'.recovered'));
 console.log(JSON.stringify({restored,gone,files:files.length}));})();`;
    const r = spawnSync(process.execPath, ['-e', code], { cwd: ROOT, encoding: 'utf8', timeout: 600000, maxBuffer: 64 * 1024 * 1024 });
    if (r.status !== 0) throw new Error((r.stderr || r.stdout || '').trim().split('\n').slice(-5).join('\n'));
    return JSON.parse(r.stdout.trim().split('\n').pop());
}

function stateOf(src) {
    const m = MARK_RE.exec(src);
    if (m) return { kind: 'patched', version: Number(m[1]), base: m[2] };
    if (/manifest\.journal/.test(src)) return { kind: 'legacy' };   // 예전에 손으로 넣은 패치
    return { kind: 'vanilla' };
}

async function confirm(q) {
    if (flag('--yes')) return true;
    if (!process.stdin.isTTY) return true;
    process.stdout.write(`${q} [y/N] `);
    const ans = await new Promise(r => { process.stdin.once('data', d => r(String(d).trim())); });
    process.stdin.pause();
    return /^y(es)?$/i.test(ans);
}

function writeAtomic(file, data) {
    const tmp = `${file}.rbu-tmp-${process.pid}`;
    fs.writeFileSync(tmp, data);
    const fd = fs.openSync(tmp, 'r+'); try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, file);
}

function readGitOriginal() {
    const r = spawnSync('git', ['-C', ROOT, 'show', 'HEAD:server/node/file-kv.cjs'], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
    if (r.status !== 0 || !r.stdout) return null;
    return /manifest\.journal|RBU-SPEED-PATCH/.test(r.stdout) ? null : r.stdout;
}

// ---------------------------------------------------------------- main
(async () => {
    say(`RisuBard 저장 속도 패치 v${VERSION}`);
    if (!fs.existsSync(FILE_KV)) fail(`RisuBard 폴더가 아닌 것 같아요: ${FILE_KV} 가 없습니다.\n  사용법: node rbu-speed-patch.cjs <RisuBard 폴더>`);
    let pkgVer = '?';
    try { pkgVer = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version; } catch {}
    const src = fs.readFileSync(FILE_KV, 'utf8');
    const st = stateOf(src);
    const dataRoot = dataRootOf();
    const jp = journalPath(dataRoot);
    const hasJournal = fs.existsSync(jp);
    say(`  RisuBard ${pkgVer} · ${ROOT}`);
    say(`  file-kv.cjs: ${{ patched: `패치됨(v${st.version})`, legacy: '예전 수동 패치', vanilla: '원본' }[st.kind]} · sha256 ${sha(Buffer.from(src)).slice(0, 12)}…`);
    say(`  저장 폴더: ${dataRoot}${fs.existsSync(dataRoot) ? '' : ' (없음)'}`);
    say(`  저널: ${hasJournal ? `있음 (${fs.statSync(jp).size} bytes)` : '없음'}`);

    if (MODE === 'check') {
        if (st.kind === 'vanilla') {
            const p = patchSource(src);
            say(p.ok ? '  → 이 버전에 적용할 수 있어요. (적용: node rbu-speed-patch.cjs)' : `  → 이 버전에는 자동으로 적용할 수 없어요:\n     - ${p.problems.join('\n     - ')}`);
            if (hasJournal) say('  ⚠ 원본 file-kv인데 저널이 남아 있어요. 적용하면 먼저 안전하게 처리합니다.');
        }
        return;
    }

    if (!(await confirm('RisuBard 서버가 꺼져 있나요? (pm2 stop 등) 계속할까요?'))) fail('취소했습니다.', 2);

    // 1) 남은 저널 처리 — 어떤 작업이든 먼저
    if (hasJournal) {
        if (st.kind === 'patched' || st.kind === 'legacy') {
            say('  · 남은 저널을 manifest.json에 합치는 중…');
            try { flushWith(FILE_KV, dataRoot); } catch (e) { fail(`저널을 합치지 못했어요:\n${e.message}`); }
        } else {
            // 원본 file-kv인데 저널이 있다: 업데이트 전에 비우지 못한 경우. 패치 후보 코드로 합친다.
            say('  ⚠ 원본 file-kv인데 저널이 남아 있어요(업데이트 전에 비우지 못한 경우). 패치 코드로 합칩니다.');
            const backupJ = `${jp}.rbu-saved-${Date.now()}`;
            fs.copyFileSync(jp, backupJ);
            const p = patchSource(src);
            if (!p.ok) fail(`이 버전은 자동 적용이 안 돼 저널을 합칠 수 없어요. 저널 사본: ${backupJ}`);
            const tmpLib = path.join(NODE_DIR, `.file-kv.rbu-flush-${process.pid}.cjs`);
            fs.writeFileSync(tmpLib, p.source);
            const staleBefore = new Set(fs.readdirSync(path.dirname(jp)).filter(n => n.startsWith('manifest.journal.stale-')));
            try {
                flushWith(tmpLib, dataRoot);
                const staleLeft = fs.readdirSync(path.dirname(jp)).filter(n => n.startsWith('manifest.journal.stale-') && !staleBefore.has(n));
                if (staleLeft.length) {
                    say('  ⚠ 저널이 지금 manifest와 맞지 않아요(그 사이 순정 서버가 켜져 저장한 것으로 보입니다). 목록에서 빠진 항목만 되살립니다.');
                    const r = recoverOrphans(tmpLib, dataRoot, [...staleLeft, path.basename(backupJ)]);
                    say(`  · 되살린 항목 ${r.restored}개${r.gone ? ` · 실제 파일이 없어 못 살린 항목 ${r.gone}개` : ''} (이미 있던 항목은 더 새 값이라 그대로 둠)`);
                } else {
                    fs.renameSync(backupJ, `${backupJ}.recovered`);
                    say(`  · 합쳤어요.`);
                }
            } catch (e) { fail(`저널을 합치지 못했어요(사본: ${backupJ}):\n${e.message}`); }
            finally { try { fs.unlinkSync(tmpLib); } catch {} }
        }
        if (fs.existsSync(jp)) fail('저널이 아직 남아 있어요. 서버가 켜져 있는 건 아닌지 확인해 주세요.');
    }

    if (MODE === 'flush') { say('완료: 저널이 비어 있어요.'); return; }

    if (MODE === 'uninstall') {
        if (st.kind === 'vanilla') { say('이미 원본이에요.'); return; }
        let original = null;
        if (st.kind === 'patched' && fs.existsSync(BACKUP)) {
            const b = fs.readFileSync(BACKUP, 'utf8');
            if (sha(Buffer.from(b)) === st.base) original = b;
        }
        original ??= readGitOriginal();
        if (!original) fail('원본 file-kv.cjs를 찾지 못했어요(백업도 git 원본도 없음). RisuBard를 다시 받거나 업데이트해 주세요. 저널은 이미 비워 두었어요.');
        writeAtomic(FILE_KV, original);
        say('완료: 원본으로 되돌렸어요. 서버를 다시 켜세요.');
        return;
    }

    // install
    let base = src;
    if (st.kind === 'patched') {
        if (st.version >= VERSION) { say('이미 적용돼 있어요. 서버를 켜면 됩니다.'); return; }
        const b = fs.existsSync(BACKUP) ? fs.readFileSync(BACKUP, 'utf8') : null;
        base = (b && sha(Buffer.from(b)) === st.base) ? b : readGitOriginal();
        if (!base) fail('이전 버전 패치의 원본을 찾지 못했어요. RisuBard를 다시 받은 뒤 실행해 주세요.');
    } else if (st.kind === 'legacy') {
        say('  · 예전에 손으로 넣은 패치예요. git 원본을 찾아 새 방식으로 다시 적용합니다.');
        base = readGitOriginal();
        if (!base) fail('원본 file-kv.cjs를 찾지 못했어요. `git checkout server/node/file-kv.cjs` 또는 RisuBard를 다시 받은 뒤 실행해 주세요.\n  (저널은 이미 비워 두었어요.)');
    }

    const p = patchSource(base);
    if (!p.ok) fail(`이 버전에는 자동으로 적용할 수 없어요. 아무것도 바꾸지 않았습니다.\n     - ${p.problems.join('\n     - ')}\n  개발자가 저장 코드를 바꾼 버전일 수 있어요. 새 패치기가 나올 때까지 원본으로 쓰세요.`);
    say('  · 고칠 자리를 모두 찾았어요. 이 버전의 서버 파일로 자체 시험 중… (30초~1분)');
    const t = runSelfTest(p.source);
    if (!t.ok) fail(`자체 시험에 실패해 적용하지 않았어요. 아무것도 바꾸지 않았습니다.\n${t.out.split('\n').slice(-12).join('\n')}`);
    say(`  · 자체 시험 통과 (${(t.out.match(/KILL9 acked=\d+/) || [''])[0].replace('KILL9 acked=', 'kill -9 시험 저장 ')}건 손실 0)`);
    writeAtomic(BACKUP, base);
    writeAtomic(FILE_KV, p.source);
    say(`완료: 적용했어요. 원본은 ${path.basename(BACKUP)} 에 있어요. 서버를 다시 켜세요.`);
    say('  RisuBard를 업데이트한 뒤에는 이 명령을 다시 실행하세요(남은 저널을 먼저 합친 뒤 다시 적용합니다).');
})().catch(e => fail(e?.stack || String(e)));

module.exports = { patchSource, matchBrace };
